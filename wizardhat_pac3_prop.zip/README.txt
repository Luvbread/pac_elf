Wizard Hat (PAC3 Prop)
=======================

What this is
-------------
A standalone GMod addon containing a single pointed hat model (cone shape
with a wide brim), repackaged from the "witchhat" model found in your
gmod_tower_accessories_pack so it can be used on its own as a PAC3 prop.

IMPORTANT: no new 3D model was created. This machine has no Source SDK /
Blender / Crowbar / studiomdl installed, so a brand-new custom mesh could
not be modeled and compiled. This package reuses the existing compiled
"witchhat" model (.mdl/.vvd/.vtx) and its material (.vmt/.vtf) as-is.
Source engine models cannot be renamed internally without recompiling from
source, so the in-game model path is still:

    models/gmod_tower/witchhat.mdl

That's expected -- just use that path when adding it in PAC3 (see below).

Licensing note
---------------
The witchhat model/textures originate from the GMod Tower accessories
Workshop addon, not something authored from scratch here. Fine for your
own local/personal PAC3 use. If you plan to re-upload this zip publicly to
the Steam Workshop, check the original addon's license/permissions first --
redistributing someone else's compiled content without credit or
permission can violate Workshop terms.

Folder structure (standard GMod addon layout)
-----------------------------------------------
wizardhat_pac3_prop/
  addon.json                                 addon metadata (used if uploading via gmpublish)
  models/gmod_tower/witchhat.mdl             compiled model
  models/gmod_tower/witchhat.vvd             vertex data
  models/gmod_tower/witchhat.dx80.vtx        mesh strip data (DirectX 8)
  models/gmod_tower/witchhat.dx90.vtx        mesh strip data (DirectX 9)
  models/gmod_tower/witchhat.sw.vtx          mesh strip data (software)
  materials/models/gmod_tower/witchhat.vmt   material script
  materials/models/gmod_tower/witchhat.vtf   texture

No .phy file is included -- this model has no physics collision mesh in
the source pack, which is normal/fine for a wearable PAC3 accessory (PAC3
does not need collision to bonemerge a prop onto a player).

Installation
-------------
1. Extract wizardhat_pac3_prop.zip.
2. Copy the whole "wizardhat_pac3_prop" folder into:
       <Steam>\steamapps\common\GarrysMod\garrysmod\addons\
3. Restart Garry's Mod (or reload if already running).

Using it in PAC3
------------------
1. Open the PAC3 editor (default key: F3, or via the PAC3 spawn icon).
2. Right-click your root/base part -> Add Part -> Model.
3. Select the new Model part, then in its properties open the model
   picker and browse/type:
       models/gmod_tower/witchhat.mdl
4. Position/scale/rotate it and bonemerge it to the head bone
   (ValveBiped.Bip01_Head1) like any other PAC3 hat prop.

If you want a genuinely custom wizard hat mesh (different silhouette,
stars/moons texture, wider brim, etc.) instead of this reused witch hat,
that requires actually modeling it (e.g. in Blender) and compiling it with
Crowbar/studiomdl -- none of which is installed on this machine. Let me
know if you'd like help setting that pipeline up.
